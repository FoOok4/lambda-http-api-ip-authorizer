#!/bin/bash
rm function.zip
rm -rf package

pip install ipaddress --target package
pip install uuid --target package


cd package

zip -r9 ../function.zip .

cd ../

zip authorizer_function.zip lambda_http_api_ip_validation.py zip.sh